import { recordTemperatureAction } from "@/app/actions";
import { DashboardHeader } from "@/components/dashboard-header";
import { RowActionForm } from "@/components/row-action-form";
import { StatusBadge } from "@/components/status-badge";
import { todayISODate } from "@/lib/date";
import { getPatients } from "@/lib/patient-repo";

export default async function NursePage() {
  const patients = await getPatients();
  const today = todayISODate();

  const patientsNeedingTemperature = patients.filter((patient) => {
    if (patient.status === "DISCHARGED") return false;
    return !patient.temperatureLogs.some((log) => log.date === today);
  });

  return (
    <main className="mx-auto max-w-7xl p-4 md:p-8">
      <DashboardHeader title="Nurse Dashboard" />
      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-100 text-slate-700">
            <tr>
              <th className="px-4 py-3">Patient</th>
              <th className="px-4 py-3">Room</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Fever-Free Streak</th>
              <th className="px-4 py-3">Action</th>
            </tr>
          </thead>
          <tbody>
            {patientsNeedingTemperature.map((patient) => {
              return (
                <tr key={patient.id} className="border-t border-slate-200 align-top">
                  <td className="px-4 py-3 font-medium">{patient.name}</td>
                  <td className="px-4 py-3">{patient.roomNumber}</td>
                  <td className="px-4 py-3">
                    <StatusBadge status={patient.status} />
                  </td>
                  <td className="px-4 py-3">{patient.feverFreeStreak}</td>
                  <td className="px-4 py-3">
                    <RowActionForm
                      patientId={patient.id}
                      actionLabel="Log Temperature"
                      pendingLabel="Saving..."
                      includeTemperatureInput
                      actionFn={recordTemperatureAction}
                    />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </section>
    </main>
  );
}
