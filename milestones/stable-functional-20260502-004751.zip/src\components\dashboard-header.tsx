import Link from "next/link";

const items = [
  { href: "/nurse", label: "Nurse Dashboard" },
  { href: "/doctor", label: "Doctor Dashboard" },
  { href: "/admin", label: "Admin Dashboard" },
];

export function DashboardHeader({ title }: { title: string }) {
  return (
    <header className="mb-6 flex flex-col gap-4 rounded-xl border border-slate-200 bg-white p-5 shadow-sm md:flex-row md:items-center md:justify-between">
      <div>
        <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">Virus Quarantine Facility</p>
        <h1 className="text-2xl font-semibold text-slate-900">{title}</h1>
      </div>
      <nav className="flex flex-wrap gap-2">
        {items.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100"
          >
            {item.label}
          </Link>
        ))}
      </nav>
    </header>
  );
}
