import { formatStatus } from "@/lib/date";
import type { PatientStatus } from "@/lib/types";

const tones: Record<PatientStatus, string> = {
  ADMITTED: "bg-slate-100 text-slate-800",
  TEMP_PENDING: "bg-yellow-100 text-yellow-900",
  READY_FOR_DOCTOR: "bg-sky-100 text-sky-900",
  UNDER_REVIEW: "bg-violet-100 text-violet-900",
  READY_FOR_DISCHARGE: "bg-emerald-100 text-emerald-900",
  DISCHARGED: "bg-zinc-200 text-zinc-700",
};

export function StatusBadge({ status }: { status: PatientStatus }) {
  return (
    <span className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${tones[status]}`}>
      {formatStatus(status)}
    </span>
  );
}
