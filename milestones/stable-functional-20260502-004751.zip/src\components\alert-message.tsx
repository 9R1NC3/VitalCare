export function AlertMessage({ message, ok = false }: { message?: string; ok?: boolean }) {
  if (!message) {
    return null;
  }

  return (
    <p
      className={`rounded-md px-3 py-2 text-sm ${
        ok ? "bg-emerald-100 text-emerald-900" : "bg-rose-100 text-rose-900"
      }`}
    >
      {message}
    </p>
  );
}
