"use client";

import { useActionState, useMemo } from "react";
import { addPatientAction, type ActionResult } from "@/app/actions";
import { AlertMessage } from "@/components/alert-message";

const initialState: ActionResult = { ok: false, message: "" };

export function AddPatientForm() {
  const [state, action, pending] = useActionState(addPatientAction, initialState);
  const isSuccess = useMemo(() => state.ok && !!state.message, [state]);

  return (
    <form action={action} className="grid gap-3 rounded-lg border border-slate-200 bg-white p-4 shadow-sm md:grid-cols-[1fr_160px_auto]">
      <input
        name="name"
        placeholder="Patient name"
        required
        className="rounded-md border border-slate-300 px-3 py-2 text-sm outline-none ring-sky-200 focus:ring"
      />
      <input
        name="roomNumber"
        placeholder="Room #"
        required
        className="rounded-md border border-slate-300 px-3 py-2 text-sm uppercase outline-none ring-sky-200 focus:ring"
      />
      <button
        type="submit"
        disabled={pending}
        className="rounded-md bg-slate-900 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
      >
        {pending ? "Admitting..." : "Admit Patient"}
      </button>
      <div className="md:col-span-3">
        <AlertMessage message={state.message} ok={isSuccess} />
      </div>
    </form>
  );
}
