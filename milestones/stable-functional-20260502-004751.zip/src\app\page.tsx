import Link from "next/link";

export default function Home() {
  return (
    <main className="mx-auto flex min-h-screen w-full max-w-4xl flex-col items-center justify-center px-4 py-10">
      <div className="w-full rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
        <p className="text-sm font-semibold uppercase tracking-wider text-slate-500">
          Virus Quarantine & Treatment Facility
        </p>
        <h1 className="mt-2 text-3xl font-bold text-slate-900">Operations Console</h1>
        <p className="mt-3 text-slate-600">
          Choose a role-specific dashboard to manage daily patient care workflow.
        </p>
        <div className="mt-8 grid gap-3 sm:grid-cols-3">
          <Link href="/nurse" className="rounded-lg border border-slate-300 p-4 text-sm font-semibold text-slate-800 hover:bg-slate-50">
            Nurse Dashboard
          </Link>
          <Link href="/doctor" className="rounded-lg border border-slate-300 p-4 text-sm font-semibold text-slate-800 hover:bg-slate-50">
            Doctor Dashboard
          </Link>
          <Link href="/admin" className="rounded-lg border border-slate-300 p-4 text-sm font-semibold text-slate-800 hover:bg-slate-50">
            Admin Dashboard
          </Link>
        </div>
        <p className="mt-6 text-xs text-slate-500">
          First-time setup: set Firebase env vars, then call POST /api/patients/seed once.
        </p>
      </div>
    </main>
  );
}
