import { dischargePatientAction } from "@/app/actions";
import { AddPatientForm } from "@/components/add-patient-form";
import { DashboardHeader } from "@/components/dashboard-header";
import { RowActionForm } from "@/components/row-action-form";
import { StatCard } from "@/components/stat-card";
import { StatusBadge } from "@/components/status-badge";
import { MAX_CAPACITY } from "@/lib/constants";
import { getOccupancyStats, getPatients } from "@/lib/patient-repo";

export default async function AdminPage() {
  const [patients, stats] = await Promise.all([getPatients(), getOccupancyStats()]);
  const dischargeCandidates = patients.filter((p) => p.status === "READY_FOR_DISCHARGE");

  return (
    <main className="mx-auto max-w-7xl space-y-6 p-4 md:p-8">
      <DashboardHeader title="Admin Dashboard" />

      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Current Occupancy" value={`${stats.occupiedBeds}/${MAX_CAPACITY}`} />
        <StatCard label="Discharge Ready" value={stats.dischargeReadyCount} />
        <StatCard label="Discharged" value={stats.dischargedCount} />
        <StatCard label="Mortality Rate (Dummy)" value={`${stats.mortalityRate}%`} />
      </section>

      <AddPatientForm />

      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-100 text-slate-700">
            <tr>
              <th className="px-4 py-3">Patient</th>
              <th className="px-4 py-3">Room</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Action</th>
            </tr>
          </thead>
          <tbody>
            {dischargeCandidates.map((patient) => {
              return (
                <tr key={patient.id} className="border-t border-slate-200 align-top">
                  <td className="px-4 py-3 font-medium">{patient.name}</td>
                  <td className="px-4 py-3">{patient.roomNumber}</td>
                  <td className="px-4 py-3">
                    <StatusBadge status={patient.status} />
                  </td>
                  <td className="px-4 py-3">
                    <RowActionForm
                      patientId={patient.id}
                      actionLabel="Discharge"
                      pendingLabel="Discharging..."
                      actionFn={dischargePatientAction}
                    />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </section>

      <p className="text-sm text-slate-600">
        Total discharge-ready patients right now: <strong>{dischargeCandidates.length}</strong>
      </p>
    </main>
  );
}
